//
//  sprintStruct.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/17/21.
//

import Foundation
import FirebaseFirestoreSwift

struct Workout: Codable, Identifiable{
    @DocumentID var id:String?
    var distance: String
    var time: String
    
}
