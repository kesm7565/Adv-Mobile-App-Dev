//
//  workoutsDataHandler.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/18/21.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class WorkoutsDataHandler{
    let db = Firestore.firestore()
    var workoutData = [Workout]()
    var onDataUpdate: ((_ data: [Workout])-> Void)?
    
    func dbSetup(){
        db.collection("workouts")
            .addSnapshotListener {querySnapshot, error in guard let documents = querySnapshot?.documents else{
                print("Error fetching snapshot results: \(error!)")
                return
            }
            self.workoutData = documents.compactMap {document->Workout? in return try? document.data(as: Workout.self)
                
            }
            self.onDataUpdate?(self.workoutData)
            
            }
    }
    func getWorkouts()->[Workout]{
        return workoutData
    }
    
    func addWorkout(distance: String, time: String){
        let workoutCollection = db.collection("workouts")
        let newWorkoutDict = ["distance": distance, "time": time]
        var ref: DocumentReference? = nil
        ref = workoutCollection.addDocument(data: newWorkoutDict)
        {err in
            if let err = err{
                print("Error adding document: \(err)")
            }
            else{
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    
    func deleteWorkout(workoutID: String){
        db.collection("workouts").document(workoutID).delete()
    }
    
}

