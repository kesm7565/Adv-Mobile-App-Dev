//
//  workouts.swift
//  Lab 6
//
//  Created by Kendal Smith on 3/16/21.
//

import Foundation
import FirebaseFirestoreSwift

struct Workout: Codable, Identifiable{
    @DocumentID var id:String?
    var distance: String
    var time: String
    
}
