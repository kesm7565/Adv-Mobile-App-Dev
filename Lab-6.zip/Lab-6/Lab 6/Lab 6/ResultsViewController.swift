//
//  ResultsViewController.swift
//  Lab 6
//
//  Created by Kendal Smith on 3/16/21.
//

import UIKit

class ResultsViewController: UIViewController {
    @IBOutlet weak var distanceTextField: UITextField!
    @IBOutlet weak var timeTextField: UITextField!
    
    var addeddistance = String()
    var addedtime = String()
    
    override func prepare(for segue: UIStoryboardSegue, sender:Any?){
        if segue.identifier == "saveSegue"{
            if distanceTextField.text?.isEmpty == false {
                addeddistance = distanceTextField.text!
                addedtime = timeTextField.text!
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
