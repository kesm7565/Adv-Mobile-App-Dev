//
//  DatePickerViewController.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/31/21.
//

import UIKit
import QuartzCore

class DatePickerViewController: UIViewController {

    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var goToDateButton: UIButton!
    
    @IBAction func goToDateButton(_ sender: Any) {
        
        let components = datePicker.calendar.dateComponents([.era, .year, .month, .day],
                                                        from: datePicker.date)
        print("\(String(describing: components.era)) \(String(describing: components.year)) \(String(describing: components.month)) \(String(describing: components.day))")
        
    }
    @IBAction func datePicker(_ sender: UIDatePicker) {
        
        
        
    }
    override func viewDidLoad() {
        

        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
