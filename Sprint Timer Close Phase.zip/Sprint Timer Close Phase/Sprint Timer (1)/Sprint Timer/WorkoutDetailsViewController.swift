//
//  WorkoutDetailsViewController.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/30/21.
//

import UIKit

class WorkoutDetailsViewController: UIViewController {
    
   
    
    @IBOutlet weak var repLabel2: UILabel!
  
    var workouts = [Workout]()
    
    var workoutDataHandler = WorkoutsDataHandler()
    
    @IBOutlet weak var distanceLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var restLabel: UILabel!
    
    var finalRep = ""
    var timeSend0 = ""
    var distSend0 = ""
    var restSend0 = ""
    
    
    func display(){
        repLabel2.text = finalRep
        distanceLabel.text = "Run " + distSend0 + " Meters"
        timeLabel.text = "Complete rep in " + timeSend0 + " Seconds"
        restLabel.text = "Rest for " + restSend0 + " Minutes"
        
        //print(finalRep)
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        workoutDataHandler.onDataUpdate = {[weak self] (data:[Workout]) in self?.render()}
        workoutDataHandler.dbSetup()
        // Do any additional setup after loading the view.
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        display()
    }
    func render(){
        workouts = workoutDataHandler.getWorkouts()
      //  tableView.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
