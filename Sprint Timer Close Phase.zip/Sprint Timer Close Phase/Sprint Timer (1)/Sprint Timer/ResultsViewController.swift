//
//  ResultsViewController.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/18/21.
//

import UIKit

class ResultsViewController: UIViewController {
    var repFinal = ""
    var workouts = [Workout]()
    var workoutDataHandler = WorkoutsDataHandler()
    
    
    
    @IBOutlet weak var repLabel: UILabel!
    
    @IBOutlet weak var distanceTextField: UITextField!
    
    @IBOutlet weak var timeTextField: UITextField!
    
    @IBOutlet weak var restTextField: UITextField!
    
    var addeddistance = String()
    var addedtime = String()
    var addedrest = String()
    
    
    override func prepare(for segue: UIStoryboardSegue, sender:Any?){
        if segue.identifier == "saveSegue"{
            if distanceTextField.text?.isEmpty == false {
                addeddistance = distanceTextField.text!
                addedtime = timeTextField.text!
                addedrest = restTextField.text!
                
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        repLabel.text = repFinal

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

