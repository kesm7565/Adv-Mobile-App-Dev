//
//  timerView.swift
//  Sprint Timer
//
//  Created by Kendal Alexander Smith on 2/23/21.
//

import UIKit
import Foundation
import AVFoundation
private var audioLevel : Float = 0.0


class timerView: UIViewController {
   
    @IBOutlet weak var currentRep: UILabel!
    
    @IBOutlet weak var volumeButtonSwitch: UISwitch!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var submitWorkout: UIButton!
    var dates = [Date]()
    var workoutDataHandler = WorkoutsDataHandler()
    var timer:Timer = Timer();
    var count:Int = 0;
    var timerCounting:Bool = false;
    var currentRep2 = 0;
    var finalRep = ""
    var timeSend0 = ""
    var distSend0 = ""
    var restSend0 = ""
    var repCounter = 1;
    var distArrayReciever: [Int] = []
    var restArrayReciever: [Int] = []
    var timeArrayReciever: [Int] = []
    var workoutDateArray: [String] = []
    var restLeft = 0;
    var countUp:Bool = false;
    var countDown:Bool = false;
    var time0 = 0;
    var k = 0;
    var resetToggle: Bool = false;
    var timeString = "";
    var vc = savedWorkoutsViewController()
    var senderString = "";
    var finishedWorkout = "";
    let currentDate0 = Date()
    let formatter = DateFormatter()
    var currentDate = ""
    let calendar = Calendar.current
    var workoutArrayString = ""
    
    @IBAction func submitWorkoutButton(_ sender: UIButton) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "submitWorkoutSegue"{
            
            
            
        formatter.dateFormat = "MM.dd.yyyy"
        let result = formatter.string(from: currentDate0)

        
        finishedWorkout = senderString
        currentDate = result
        
        print(workoutArrayString)
        print(finishedWorkout, currentDate)
        
        let vc = segue.destination as? savedWorkoutsViewController
        vc?.currentDate0 = currentDate
        vc?.text = finishedWorkout
            
        }
    }
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        workoutDataHandler.dbSetup()
        startButton.setTitleColor(UIColor.green, for: .normal)
       currentRep.text = "Start Your Workout"
       
        
    }
    
    
    @IBAction func startButton(_ sender: Any) {
   
        if(timerCounting)
        {
            timerCounting = false
            timer.invalidate()
            startButton.setTitle("START", for: .normal)
            startButton.setTitleColor(UIColor.green, for: .normal)
        }
        
        else
        {
            timerCounting = true
            startButton.setTitle("STOP", for: .normal)
            startButton.setTitleColor(UIColor.red, for: .normal)
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(timerCounter), userInfo: nil, repeats: true)
            
            if (resetToggle == false){
                timerCountUp();
                
                
            }
            else if (resetToggle == true){
                timerCountDown();
            }
        }
        
    }
    
    func fullWorkout(){
        
        workoutDateArray.append("Rep: " + String(repCounter-1) + " - Distance: " + String(distArrayReciever[k]) + " - Time: " +  timeString)
        senderString = workoutDateArray.joined(separator:" \n")
      
        
    }
    func timerCountUp(){
        countUp = true;
        countDown = false;
        k = repCounter - 1
        if(repCounter >= currentRep2){
            currentRep.text = "Your workout is over!"
            k = 0;
        }
        else{
        currentRep.text = "Rep " + String(repCounter) + ": " + String(distArrayReciever[k]) + " Meters"
        }
    }
    
    func timerCountDown(){
        countDown = true;
        countUp = false;
        if(k>=0){
            count = ((Int(restArrayReciever[k]) * 6000) % 360000)
        currentRep.text = "Rest for: " + String(restArrayReciever[k]) + " Minutes"
        }
        else{
         currentRep.text = "Enter workout in previous view!"
        }
    }
    
    @objc func timerCounter() -> Void
    {
        
        if (countUp == true){
        count = count + 1
        }
        else if (countDown == true){
        count = count - 1
        }
        let time0 = secondsToHoursMinutesSeconds(milliseconds: count)
        
        timeString = makeTimeString(minutes: time0.0, seconds: time0.1, milliseconds: (time0.2))
        timerLabel.text = timeString
      
        
        if (self.count < 0){
            self.count = 0
            self.timer.invalidate()
            self.timerLabel.text = self.makeTimeString(minutes: 0, seconds: 0, milliseconds: 0)
            self.startButton.setTitle("START", for: .normal)
            self.startButton.setTitleColor(UIColor.green, for: .normal)
 
        }
    }
    
    func secondsToHoursMinutesSeconds(milliseconds: Int) -> (Int, Int, Int)
    {
        
        return (((milliseconds/6000 % 36000)), ((milliseconds/100 % 36000) % 60), ((milliseconds % 36000) % 100))
        
    }
    
    func makeTimeString(minutes: Int, seconds: Int, milliseconds: Int) -> String{
        var timeString = ""
        timeString += String(format: "%02d", minutes)
        timeString += " : "
        timeString += String(format: "%02d", seconds)
        timeString += " : "
        timeString += String(format: "%02d", milliseconds)
        return timeString
    }
    
    @IBAction func volumeButtonSwitch(_ sender: UISwitch) {
        
        if sender.isOn{
            volumeButtonSwitch.onTintColor = .green
            
            let alert = UIAlertController(title: "Start timer with volume buttons?", message: "Using volume buttons to stop and start timer will result in volume change.", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (_) in
                
            } ))
            
            self.present(alert, animated: true, completion: nil)
            
            listenVolumeButton();
        }
        else{
            volumeButtonSwitch.onTintColor = .red
        }
        
    }
    func listenVolumeButton(){
            
             let audioSession = AVAudioSession.sharedInstance()
             do {
                  try audioSession.setActive(true, options: [])
             audioSession.addObserver(self, forKeyPath: "outputVolume",
                                      options: NSKeyValueObservingOptions.new, context: nil)
                  audioLevel = audioSession.outputVolume
             } catch {
                  print("Error")
             }
        }
       
        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
             if keyPath == "outputVolume"{
                  let audioSession = AVAudioSession.sharedInstance()
                  if audioSession.outputVolume > audioLevel {
                       print("Hello")
                  }
                  if audioSession.outputVolume < audioLevel {
                       print("GoodBye")
                  }
                  audioLevel = audioSession.outputVolume
                  //print(audioSession.outputVolume)
             }
        }
    @IBAction func stopButton(_ sender: Any) {
        
        
        if(resetToggle == true){
            resetToggle = false;
            
        }
        else if(resetToggle == false){
            if(repCounter < currentRep2){
                repCounter = repCounter + 1;
                fullWorkout();
                
            }
            else{
                currentRep.text = "Your workout is over!"
            }
            resetToggle = true;
        }
        self.count = 0
        self.timer.invalidate()
        self.timerLabel.text = self.makeTimeString(minutes: 0, seconds: 0, milliseconds: 0)
        self.startButton.setTitle("START", for: .normal)
        self.startButton.setTitleColor(UIColor.green, for: .normal)
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
