//
//  workoutsDataHandler.swift
//  Sprint Timer
//
//  Created by Kendal Smith on 3/18/21.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class WorkoutsDataHandler{
    let db = Firestore.firestore()
    var workoutData = [Workout]()
    var onDataUpdate: ((_ data: [Workout])-> Void)?
    var dateData = [Date0]()
    var onDataUpdate2: ((_ data: [Date0])-> Void)?
    
    func dbSetup(){
        db.collection("workouts")
            .addSnapshotListener {querySnapshot, error in guard let documents = querySnapshot?.documents else{
                print("Error fetching snapshot results: \(error!)")
                return
            }
            self.workoutData = documents.compactMap {document->Workout? in return try? document.data(as: Workout.self)
                
            }
            self.onDataUpdate?(self.workoutData)
            
            }
        db.collection("dates")
            .addSnapshotListener {querySnapshot, error in guard let documents = querySnapshot?.documents else{
                print("Error fetching snapshot results: \(error!)")
                return
            }
            self.dateData = documents.compactMap {document->Date0? in return try? document.data(as: Date0.self)
                
            }
            self.onDataUpdate2?(self.dateData)
            
            }
    }
    func getWorkouts()->[Workout]{
        return workoutData
    }
    func getDates()->[Date0]{
        return dateData
    }
    
    func addWorkout(distance: String, time: String, rest: String){
        let workoutCollection = db.collection("workouts")
        let newWorkoutDict = ["distance": distance, "time": time, "rest": rest]
        var ref: DocumentReference? = nil
        ref = workoutCollection.addDocument(data: newWorkoutDict)
        {err in
            if let err = err{
                print("Error adding document: \(err)")
            }
            else{
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    func addDate(completedWorkout: String, date: String){
        let workoutCollection = db.collection("dates")
        let newWorkoutDict = ["completedWorkout": completedWorkout, "date": date]
        var ref: DocumentReference? = nil
        ref = workoutCollection.addDocument(data: newWorkoutDict)
        {err in
            if let err = err{
                print("Error adding document: \(err)")
            }
            else{
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    
    func deleteWorkout(workoutID: String, dateID: String){
        db.collection("workouts").document(workoutID).delete()
        db.collection("dates").document(dateID).delete()
        
    }
    func addWorkout(workoutID: String, dateID: String){
        //db.collection("workouts").document(workoutID).insert()
        //db.collection("dates").document(dateID).insert()
    }
    
}

