//
//  timerView.swift
//  Sprint Timer
//
//  Created by Kendal Alexander Smith on 2/23/21.
//

import UIKit
import Foundation
import AVFoundation
private var audioLevel : Float = 0.0


class timerView: UIViewController {
   
    
    @IBOutlet weak var volumeButtonSwitch: UISwitch!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    
    var timer:Timer = Timer()
    var count:Int = 0
    var timerCounting:Bool = false
    
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
        startButton.setTitleColor(UIColor.green, for: .normal)
    }
    
    
    @IBAction func startButton(_ sender: Any) {
        print("test")
        
        if(timerCounting)
        {
            timerCounting = false
            timer.invalidate()
            startButton.setTitle("START", for: .normal)
            startButton.setTitleColor(UIColor.green, for: .normal)
        }
        else
        {
            timerCounting = true
            startButton.setTitle("STOP", for: .normal)
            startButton.setTitleColor(UIColor.red, for: .normal)
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerCounter), userInfo: nil, repeats: true)
        }
        
    }
    
    
    
    @objc func timerCounter() -> Void
    
    {
        count = count + 1
        let time = secondsToHoursMinutesSeconds(milliseconds: count)
        
        let timeString = makeTimeString(minutes: time.0, seconds: time.1, milliseconds: (time.2))
        timerLabel.text = timeString
        print(time)
    }
    
    func secondsToHoursMinutesSeconds(milliseconds: Int) -> (Int, Int, Int)
    {
        return (((milliseconds % 3600)/60), ((milliseconds % 3600) % 60), (milliseconds))
    }
    
    func makeTimeString(minutes: Int, seconds: Int, milliseconds: Int) -> String{
        var timeString = ""
        timeString += String(format: "%02d", minutes)
        timeString += " : "
        timeString += String(format: "%02d", seconds)
        timeString += " : "
        timeString += String(format: "%02d", milliseconds)
        return timeString
    }
    
    @IBAction func volumeButtonSwitch(_ sender: UISwitch) {
        
        if sender.isOn{
            
        }
        else{
            
        }
        
    }
    func listenVolumeButton(){
            
             let audioSession = AVAudioSession.sharedInstance()
             do {
                  try audioSession.setActive(true, options: [])
             audioSession.addObserver(self, forKeyPath: "outputVolume",
                                      options: NSKeyValueObservingOptions.new, context: nil)
                  audioLevel = audioSession.outputVolume
             } catch {
                  print("Error")
             }
        }
       
        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
             if keyPath == "outputVolume"{
                  let audioSession = AVAudioSession.sharedInstance()
                  if audioSession.outputVolume > audioLevel {
                       print("Hello")
                  }
                  if audioSession.outputVolume < audioLevel {
                       print("GoodBye")
                  }
                  audioLevel = audioSession.outputVolume
                  print(audioSession.outputVolume)
             }
        }
    @IBAction func stopButton(_ sender: Any) {
        let alert = UIAlertController(title: "Reset Sprint Timer?", message: "Are you sure you would like to reset the timer?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "CANCEL", style: .cancel, handler: { (_) in} ))
        alert.addAction(UIAlertAction(title: "YES", style: .default, handler: { (_) in
        self.count = 0
        self.timer.invalidate()
        self.timerLabel.text = self.makeTimeString(minutes: 0, seconds: 0, milliseconds: 0)
            self.startButton.setTitle("START", for: .normal)
            self.startButton.setTitleColor(UIColor.green, for: .normal)
        } ))
        
        self.present(alert, animated: true, completion: nil)
    }
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
